<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>WebSocket</title>
</head>
<body>
	<script src="js/jquery-2.1.1.min.js" type="text/javascript"></script>

    <script type="text/javascript">
        var socket;
        var selectName=$('#selectName');
        var toToken = '97005534e9997e2c2356b16b41a64631'
        var fromToken = "<?php echo md5($_POST['username']); ?>";
        var username = "<?php echo $_POST['username']; ?>";
        var msgArray={
        	"fromUser":username,
			"fromToken":fromToken,
			"toUser":'',
			"toToken":'',
			"message":"我是["+fromToken+"]给["+toToken+"]的消息",
			"type":"LOGIN"
		}
        if (!window.WebSocket) {
            window.WebSocket = window.MozWebSocket;
        }
        if (window.WebSocket) {
            socket = new WebSocket("ws://localhost:8080/ws");
            socket.onmessage = function(event) {
                var ta = document.getElementById('responseText');
                
                var obj = JSON.parse(event.data);
                ta.value = ta.value + '\n[' + obj.fromUser+']'+obj.message+'';
                $('#selectName').find('option').each(function(){
                	var user=$(this).text()
                	var token = $(this).val();
                	if(user && user.trim() !==' ' && token){
                		if(user == obj.fromUser){
                			$(this).val(obj.fromToken)
                		}else{
                			$('#selectName').append('<option value='+obj.fromToken+'>'+obj.fromUser+'</option>');
                		}
                	}
                });
                

            };
            socket.onopen = function(event) {
                var ta = document.getElementById('responseText');
                ta.value = "连接开启!\n";
                send(JSON.stringify(msgArray));
                //console.log(event)
            };
            socket.onclose = function(event) {
                var ta = document.getElementById('responseText');
                ta.value = ta.value + "连接被关闭\n";
            };
        } else {
            alert("你的浏览器不支持 WebSocket！");
        }

        function send(message) {
            if (!window.WebSocket) {
                return;
            }
            if (socket.readyState == WebSocket.OPEN) {
                socket.send(message);
            } else {
                alert("连接没有开启.");
            }
        }
        
        function clickSend(msg){
        	msgArray.message=msg;
        	msgArray.type="MSGBODY";
        	send(JSON.stringify(msgArray));
        }

        function selecUser(){
        	
        	msgArray.toToken=$('#selectName').val();
        	msgArray.toUser = $('#selectName').find("option:selected").text();
        }
    </script>
    <form onsubmit="return false;">
        <h3>WebSocket：</h3>
        <textarea id="responseText" style="width: 500px; height: 300px;"></textarea>
        <br> 
        <input type="text" name="message" id="messageId" style="width: 200px" value="" >
        <select id="selectName" style="width: 100px" onchange="selecUser()">

        	<option value="">选择接收人</option>
        	<option value="<?php echo md5($_POST['username']); ?>"><?php echo $_POST['username'] ?></option>
        </select>
        <input type="button" value="发送消息" onclick="clickSend(this.form.message.value);this.form.message.value=''">
        <input type="button" onclick="javascript:document.getElementById('responseText').value=''" value="清空聊天记录">
    </form>
    <br> 
    <br> 
</body>
</html>